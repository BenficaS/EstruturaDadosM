package br.com.exemplo.arvore.binaria;

class No {
	  public long item;
	  public No dir;
	  public No esq;
	}