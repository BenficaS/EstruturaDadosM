package br.com.exemplos.lista1;

public class No {
	public Object elemento;
	public No prox;
	
	public No (Object elem){
		elemento = elem;
		prox = null;
	}
}
