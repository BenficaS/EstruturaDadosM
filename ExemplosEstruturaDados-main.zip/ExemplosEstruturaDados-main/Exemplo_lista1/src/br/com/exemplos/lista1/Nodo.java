package br.com.exemplos.lista1;

public class Nodo {

private float dado;
private Nodo proximo;

public float getDado() {
	return dado;	
}

public void setDado(float dado) {
	this.dado=dado;
}

public Nodo getProximo() {
	return proximo;
}
public void setProximo(Nodo proximo) {
	this.proximo = proximo;
}
//insere no inicio

}
