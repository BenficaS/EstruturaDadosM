package br.com.questao1;

public interface Stack<T> {

}
