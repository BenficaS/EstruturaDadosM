package br.com.lista.pilha;

public interface Stack<T> {

}
