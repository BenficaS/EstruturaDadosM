package br.com.arranjo.pilha;

public class FullStackException extends Exception {

	public FullStackException(String string) {
		System.out.println(string);
	}

}
