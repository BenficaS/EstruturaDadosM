package br.com.arranjo.pilha;

public interface Stack<T> {

}
